riya bouu — Android App Project

এই প্রজেক্টে আপনার দেওয়া Pakhi_Love_Story_Game_Premium.html ফাইলটি Android WebView অ্যাপের মধ্যে রাখা হয়েছে।
Launcher/App name: riya bouu
Package: com.riyabouu.app

APK বানানোর নিয়ম:
1. Android Studio ইনস্টল করে এই ফোল্ডারটি Open করুন।
2. Gradle Sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. app/build/outputs/apk/debug/app-debug.apk ফাইলটি পাবেন।

নোট:
- এই পরিবেশে Android SDK/Build Tools নেই, তাই এখানে APK compile করা সম্ভব হয়নি।
- HTML-এর চারটি embedded voice clip অক্ষত রাখা হয়েছে।
- কভার ছবিটি HTML-এ থাকা Unsplash URL থেকে আসে, তাই সেটি লোড করতে ইন্টারনেট লাগতে পারে।
